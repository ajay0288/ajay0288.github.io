import numpy as np
data=np.array([[0,0],[0,1],[1,0],[1,1]])
target=np.array([[0],[1],[1],[1]])
lr=0.25
epoch=10
weight=np.random.uniform(size=(3,1))
data1 = np.concatenate((data,-np.ones((4,1))),axis=1)
print(data1)
for i in range(epoch):
    net=np.dot(data1,weight)
    y=np.where( net>0,1,0)
    weight+=lr*np.dot(data1.T,target-y)
print(y)
