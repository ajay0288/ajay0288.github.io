def dis(x1,y1,x2,y2):
    return (((x1-x2)**2)+((y1-y2)**2))**0.5

def mean(li):
    x,y=0,0
    n=len(li)
    
    for i in range(n):
        x+=li[i][0]
        y+=li[i][1]
    arr=[]
    arr.append(x/n)
    arr.append(y/n)
    return arr

arr=[[1,1],[2,2],[3,3],[8,8],[8,9],[9,8],[7,9]]
flag=True
for i in range(7):
    for j in range(7):
        if (i!=j and flag):
            a=arr[i][0]
            b=arr[i][1]
            c=arr[j][0]
            d=arr[j][1]
            arr1=[]
            arr2=[]
            for k in range(7):
                arr1.append(dis(a,b,arr[k][0],arr[k][1]))
                arr2.append(dis(c,d,arr[k][0],arr[k][1]))
            
            for k in range(7):
                if arr1[k]<arr2[k]:
                    arr1[k]=1
                    arr2[k]=0
                else:
                    arr1[k]=0
                    arr2[k]=1
            c1=[]
            c2=[]
            for k in range(7):
                if arr1[k]==1:
                    c1.append(arr[k])
                else:
                    c2.append(arr[k])
            
            mu1=mean(c1)
            mu2=mean(c2)
            a=mu1[0]
            b=mu1[1]
            c=mu2[0]
            d=mu2[1]
            arr3=[]
            arr4=[]
            for k in range(7):
                arr3.append(dis(a,b,arr[k][0],arr[k][1]))
                arr4.append(dis(c,d,arr[k][0],arr[k][1]))
            for k in range(7):
                if arr3[k]<arr4[k]:
                    arr3[k]=1
                    arr4[k]=0
                else:
                    arr3[k]=0
                    arr4[k]=1
            if arr1==arr3:
                print(arr3)
                print(mu1,mu2)
                flag=False
