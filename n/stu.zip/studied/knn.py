import numpy as np

def knn(k,data,target,inputs):
    nin=np.shape(inputs)[0]
    closest = np.zeros(nin)
    for n in range(nin):
        dist = np.sum((data-inputs[n,:])**2,axis=1)
        indices = np.argsort(dist,axis=0)
        print(dist,indices)
    classes = np.unique(target[indices[:k]])
    print(classes)
    if len(classes)==1:
        closest[n] = np.unique(classes)
    else:
        counts = np.zeros(max(classes)+1)
    for i in range(k):
        counts[target[indices[i]]] += 1
        print(target[indices[i]],indices[i])
    print(counts)
    closest[n] = np.max(counts)
    
    return closest

d = np.array([[7,7],[7,4],[3,4],[1,4]])
t=np.array([[0],[0],[1],[1]])
s=np.array([[3,7]])
print(knn(3,d,t,s))
