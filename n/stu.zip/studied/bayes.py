#bayes
import numpy as np
import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
'''d = pd.read_csv('E:/study/Machine Learning/lab/3.2/data.csv')
d = np.asarray(d)'''
d= [[1,1,1,1],[2,2,2,2],[3,3,3,3],[4,4,4,4]]
d=np.asarray(d)
x = d[:,0:3]
y = d[:,3]
print(x)
print(y)
r = MultinomialNB()
r = r.fit(x,y)
predict_y=r.predict(x)
print(predict_y)
print('Accuracy',accuracy_score(y,predict_y)*100)
print('CM',confusion_matrix(y,predict_y))

#desicion tree
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
d= [[1,1,1,1],[2,2,2,2],[3,3,3,3],[4,4,4,4]]
d=np.asarray(d)
x = d[:,0:3]
y = d[:,3]
print(x)
print(y)
r = DecisionTreeClassifier()
r = r.fit(x,y)
predict_y=r.predict(x)
print(predict_y)
print('Accuracy',accuracy_score(y,predict_y)*100)
print('CM',confusion_matrix(y,predict_y))

#svm
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix
'''d = pd.read_csv('E:/study/Machine Learning/lab/3.2/data.csv')
d = np.asarray(d)'''
d= [[1,1,1,1],[2,2,2,2],[3,3,3,3],[4,4,4,4]]
d=np.asarray(d)
x = d[:,0:3]
y = d[:,3]
print(x)
print(y)
r=SVC()
r = r.fit(x,y)
predict_y=r.predict(x)
print(predict_y)
print('Accuracy',accuracy_score(y,predict_y)*100)
print('CM',confusion_matrix(y,predict_y))
