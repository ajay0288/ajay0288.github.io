import numpy as np
x=np.array([[2.072345,3.241693],[17.9367,15.784810],[1.08357,7.319176],[11.120670,14.406780],[23.711550,2.557729]])
'''nin=x.shape[0]
k=2
c=x[0:k,:]
d=np.zeros(shape=(nin,k))
for i in range(nin):
	for j in range(k):
		dis=(x[i:i+1,:]-c[j:j+1,:])**2
		d[i][j]=np.sqrt(dis.sum(1))
		print(dis,d[i][j],sep='--------',end='\n\n')
print(d.T)'''

def euc(point,center):
        return (np.sum((point-center)**2 , axis=1))**0.5

for i in x:
        print(euc(x,i));
