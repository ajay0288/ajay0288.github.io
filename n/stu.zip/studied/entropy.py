import pandas as pd
import numpy as np
s=pd.read_csv("entropy.csv")
s=np.asarray(s)
n=np.shape(s)[0]
t=s[:,3:4]
pos_v=np.unique(t)
print(t)
e=len(pos_v)
freq = []
for i in range(e):
	t=pos_v[i]
	freq.append(np.sum(np.where(t,1,0)))
for i in range(e):
	if(freq[i]):
		res-=np.sum((freq[i]/n)*np.log2(freq[i]/n))
print(res)
